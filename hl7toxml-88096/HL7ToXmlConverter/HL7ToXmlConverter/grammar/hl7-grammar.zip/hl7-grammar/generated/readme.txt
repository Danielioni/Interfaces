HL7 Version 2.31
-------------------------------------------------------------------------------------------
hl7_231_generated_EDITED.dat statt hl7_231_generated_DO_NO_USE_ME.dat

Nur so wird eine hohe Kompatibilit�t zur Version 2.4 gesichert.
-------------------------------------------------------------------------------------------